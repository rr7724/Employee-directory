# Ajackus Frontend Assignment - Employee Directory

## 📌 Overview

A responsive web app to manage employee records using HTML, CSS, JS, and Freemarker (with mock data only).

## 🚀 How to Run

1. Clone the repo
2. Open `templates/dashboard.ftl` via Freemarker server
3. Use `form.html` to add or edit employees

## 📁 Project Structure

- `templates/` – Freemarker templates
- `js/` – JavaScript logic
- `css/` – Styling
- `data/` – Mock data (local array)
- `form.html` – Add/Edit form

## ✨ Features

- Employee list with Edit/Delete
- Add/Edit form with validation
- Filter, search, and sort
- Responsive UI
- No backend, in-memory data

## 🔍 Challenges & Improvements

- Handling persistence without a backend was tricky
- Could improve UX with modals for filtering
- Would refactor with a framework (e.g., React) for better state handling
